<?php $__env->startSection('content'); ?>
<div class="container-fluid flex-grow-1 container-p-y">
    <!-- Header -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-4">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                <div>
                    <h4 class="fw-bold mb-1" style="font-family: 'Hind', sans-serif;">सदस्य निर्देशिका (Society Members Directory)</h4>
                    <p class="text-muted mb-0">Total <?php echo e($members->total()); ?> registered society members across all schemes and agent districts.</p>
                </div>
                <a href="<?php echo e(route('admin.members.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-user-plus me-1"></i> Add New Member
                </a>
            </div>
        </div>
    </div>

    <!-- Filters & Search -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.members.index')); ?>" method="GET" class="row g-3">
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="Search by name, member no, mobile, aadhaar..." value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="<?php echo e((auth()->check() && auth()->user()->isAgent() && auth()->user()->agent_id) ? 'col-lg-5' : 'col-lg-3'); ?> col-md-6 col-12">
                    <select name="scheme_id" class="form-select" onchange="this.form.submit()">
                        <option value="">All Schemes (सभी योजनाएं)</option>
                        <?php $__currentLoopData = $schemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sch->id); ?>" <?php echo e(request('scheme_id') == $sch->id ? 'selected' : ''); ?>><?php echo e($sch->name_hindi); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if(!(auth()->check() && auth()->user()->isAgent() && auth()->user()->agent_id)): ?>
                <div class="col-lg-3 col-md-6 col-12">
                    <select name="agent_id" class="form-select" onchange="this.form.submit()">
                        <option value="">All Agents (सभी एजेंट)</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($agt->id); ?>" <?php echo e(request('agent_id') == $agt->id ? 'selected' : ''); ?>><?php echo e($agt->name); ?> (<?php echo e($agt->agent_code); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="col-lg-2 col-md-6 col-12 d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                    <a href="<?php echo e(route('admin.members.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Members Table -->
    <div class="card border-0 shadow-sm">
        <div class="table-responsive text-nowrap">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Member No</th>
                        <th>Member Name & Details</th>
                        <th>Scheme</th>
                        <th>Age / DOB</th>
                        <th>Agent</th>
                        <th>सहयोग दर (प्रति कार्यक्रम)</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.members.show', $m->id)); ?>" class="fw-bold text-primary">
                                <?php echo e($m->membership_no); ?>

                            </a>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="avatar avatar-sm bg-label-primary rounded-circle d-flex align-items-center justify-content-center overflow-hidden" style="width: 38px; height: 38px; flex-shrink: 0;">
                                    <?php if(!empty($m->photo_src)): ?>
                                        <img src="<?php echo e($m->photo_src); ?>" alt="<?php echo e($m->full_name); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                    <?php else: ?>
                                        <i class="fas <?php echo e($m->gender == 'Female' ? 'fa-female' : 'fa-user'); ?>"></i>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <strong class="d-block text-heading"><?php echo e($m->full_name); ?></strong>
                                    <small class="text-muted"><i class="fas fa-phone-alt me-1" style="font-size: 10px;"></i><?php echo e($m->mobile); ?> | Gotra: <?php echo e($m->gotra ?? 'N/A'); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge <?php echo e($m->scheme && $m->scheme->code == 'SENIOR' ? 'bg-label-primary' : 'bg-label-warning'); ?>">
                                <?php echo e($m->scheme ? $m->scheme->name_hindi : 'N/A'); ?>

                            </span>
                        </td>
                        <td>
                            <span class="fw-semibold"><?php echo e($m->age); ?> Yrs</span>
                            <small class="d-block text-muted"><?php echo e($m->dob ? $m->dob->format('d M Y') : ''); ?></small>
                        </td>
                        <td>
                            <span><?php echo e($m->agent ? $m->agent->name : 'HQ Direct'); ?></span>
                            <small class="d-block text-muted"><?php echo e($m->agent ? $m->agent->district : ''); ?></small>
                        </td>
                        <td>
                            <strong class="text-success">₹<?php echo e(number_format($m->monthly_support_amount)); ?>/कार्यक्रम</strong>
                            <?php if($m->pending_amount > 0): ?>
                                <small class="d-block text-danger"><i class="fas fa-exclamation-circle me-1"></i>Due: ₹<?php echo e(number_format($m->pending_amount)); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($m->status == 'Active'): ?>
                                <span class="badge bg-success">Active</span>
                            <?php elseif($m->status == 'Inactive'): ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e($m->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="btn-group btn-group-sm">
                                <a href="<?php echo e(route('admin.members.show', $m->id)); ?>" class="btn btn-outline-primary" title="View Profile">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.members.edit', $m->id)); ?>" class="btn btn-outline-info" title="Edit Member">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?php echo e(route('admin.members.ledger.pdf', $m->id)); ?>" class="btn btn-outline-danger" title="Download Ledger Card PDF" target="_blank">
                                    <i class="fas fa-file-invoice"></i>
                                </a>
                                <a href="<?php echo e(route('admin.certificates.show', $m->id)); ?>" class="btn btn-outline-warning" title="Certificate" target="_blank">
                                    <i class="fas fa-certificate"></i>
                                </a>
                                <a href="<?php echo e(route('admin.payments.create', ['member_id' => $m->id])); ?>" class="btn btn-outline-success" title="Record Payment">
                                    <i class="fas fa-rupee-sign"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="fas fa-users-slash fs-1 d-block mb-2"></i>
                            No members found matching your search filters.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer py-3">
            <?php echo e($members->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\shrishyamcrm\project\resources\views/admin/members/index.blade.php ENDPATH**/ ?>