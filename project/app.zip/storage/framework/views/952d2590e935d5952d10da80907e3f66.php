<?php if($paginator->hasPages()): ?>
    <nav class="d-flex justify-content-between align-items-center flex-wrap gap-2 w-100 py-2" aria-label="Page navigation">
        
        <div class="text-muted small">
            <?php if($paginator instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
                Showing <span class="fw-semibold text-dark"><?php echo e($paginator->firstItem() ?? 0); ?></span> to <span class="fw-semibold text-dark"><?php echo e($paginator->lastItem() ?? 0); ?></span> of <span class="fw-semibold text-dark"><?php echo e($paginator->total()); ?></span> results
            <?php endif; ?>
        </div>

        
        <ul class="pagination pagination-sm mb-0">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span class="page-link shadow-none" aria-hidden="true">
                        <i class="fas fa-chevron-left me-1 small"></i> Previous
                    </span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <i class="fas fa-chevron-left me-1 small"></i> Previous
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(is_string($element)): ?>
                        <li class="page-item disabled" aria-disabled="true"><span class="page-link"><?php echo e($element); ?></span></li>
                    <?php endif; ?>

                    
                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <li class="page-item active" aria-current="page"><span class="page-link fw-bold"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        Next <i class="fas fa-chevron-right ms-1 small"></i>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link shadow-none" aria-hidden="true">
                        Next <i class="fas fa-chevron-right ms-1 small"></i>
                    </span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php elseif($paginator instanceof \Illuminate\Pagination\LengthAwarePaginator && $paginator->total() > 0): ?>
    <div class="d-flex justify-content-between align-items-center w-100 py-2 text-muted small">
        <div>
            Showing <span class="fw-semibold text-dark"><?php echo e($paginator->firstItem() ?? 0); ?></span> to <span class="fw-semibold text-dark"><?php echo e($paginator->lastItem() ?? 0); ?></span> of <span class="fw-semibold text-dark"><?php echo e($paginator->total()); ?></span> results
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\laravel_project\shrishyamcrm\project\resources\views/vendor/pagination/bootstrap-5.blade.php ENDPATH**/ ?>