<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
	<div class="app-brand demo py-3" style="height: auto; min-height: 75px;">
		<a href="<?php echo e(route('admin.dashboard')); ?>" class="app-brand-link d-flex align-items-center gap-2">
			<span class="app-brand-logo demo">
				<img src="<?php echo e(asset('assets/logo.svg')); ?>" alt="Shri Shyam Welfare Society Logo" style="width: 38px; height: 38px; object-fit: contain;">
			</span>
			<div class="d-flex flex-column text-start">
				<span class="app-brand-text fw-bold text-heading fs-6 lh-1 mb-1" style="font-family: 'Hind', sans-serif;"><?php echo e(__('erp.app_name_hindi')); ?></span>
				<small class="text-muted fw-semibold" style="font-size: 11px; letter-spacing: 0.5px;"><?php echo e(__('erp.welfare_society_erp')); ?></small>
			</div>
		</a>

		<a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
			<i class="bx bx-chevron-left bx-sm align-middle"></i>
		</a>
	</div>

	<div class="menu-inner-shadow"></div>

	<ul class="menu-inner py-2">
		<!-- Main Menu -->
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.main_menu')); ?></span>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-chart-pie"></i>
				<div><?php echo e(__('erp.dashboard')); ?></div>
			</a>
		</li>

		<!-- Master Records -->
		<?php if(auth()->check() && (auth()->user()->isSuperAdmin() || auth()->user()->role === 'admin' || auth()->user()->role === 'super_admin' || auth()->user()->hasRole(['admin', 'super_admin']))): ?>
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.master_records')); ?></span>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/schemes*') || request()->is('admin/age-slabs*') ? 'active open' : ''); ?>">
			<a href="javascript:void(0);" class="menu-link menu-toggle">
				<i class="menu-icon tf-icons fas fa-hand-holding-heart"></i>
				<div><?php echo e(__('erp.schemes_master')); ?></div>
			</a>
			<ul class="menu-sub">
				<li class="menu-item <?php echo e(request()->is('admin/schemes') ? 'active' : ''); ?>">
					<a href="<?php echo e(route('admin.schemes.index')); ?>" class="menu-link">
						<div><?php echo e(__('erp.all_schemes')); ?></div>
					</a>
				</li>
				<li class="menu-item">
					<a href="<?php echo e(route('admin.schemes.index')); ?>#addSchemeModal" class="menu-link" onclick="if(window.location.pathname.includes('/schemes')){ new bootstrap.Modal(document.getElementById('addSchemeModal')).show(); return false; }">
						<div><i class="fas fa-plus-circle me-1 small text-primary"></i> <?php echo e(__('erp.add_scheme')); ?></div>
					</a>
				</li>
				<li class="menu-item <?php echo e(request()->is('admin/age-slabs*') ? 'active' : ''); ?>">
					<a href="<?php echo e(route('admin.schemes.age-slabs')); ?>" class="menu-link">
						<div><?php echo e(__('erp.age_slabs')); ?></div>
					</a>
				</li>
			</ul>
		</li>

		<!-- Agent Network -->
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.agent_network')); ?></span>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/agents*') ? 'active open' : ''); ?>">
			<a href="javascript:void(0);" class="menu-link menu-toggle">
				<i class="menu-icon tf-icons fas fa-user-tie"></i>
				<div><?php echo e(__('erp.agent_network')); ?></div>
			</a>
			<ul class="menu-sub">
				<li class="menu-item <?php echo e(request()->is('admin/agents') ? 'active' : ''); ?>">
					<a href="<?php echo e(route('admin.agents.index')); ?>" class="menu-link">
						<div><?php echo e(__('erp.all_agents')); ?></div>
					</a>
				</li>
				<li class="menu-item">
					<a href="<?php echo e(route('admin.agents.index')); ?>#addAgentModal" class="menu-link" onclick="if(window.location.pathname.includes('/agents')){ new bootstrap.Modal(document.getElementById('addAgentModal')).show(); return false; }">
						<div><i class="fas fa-user-plus me-1 small text-primary"></i> <?php echo e(__('erp.add_agent')); ?></div>
					</a>
				</li>
			</ul>
		</li>
		<?php endif; ?>

		<!-- Member Enrolment -->
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.member_enrolment')); ?></span>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/members') || (request()->is('admin/members/*') && !request()->is('admin/members/create')) ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.members.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-users"></i>
				<div><?php echo e(__('erp.all_members')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/members/create') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.members.create')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-user-plus"></i>
				<div><?php echo e(__('erp.add_member')); ?></div>
			</a>
		</li>

		<!-- Collections & Accounting -->
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.collections_accounting')); ?></span>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/payment-entry*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.payments.create')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-cash-register text-success"></i>
				<div><?php echo e(__('erp.receipt_entry')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/payments') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.payments.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-history"></i>
				<div><?php echo e(__('erp.receipt_history')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/receipts*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.receipts.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-receipt"></i>
				<div><?php echo e(__('erp.receipts')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/ledger*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.ledger.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-book-open"></i>
				<div><?php echo e(__('erp.ledger')); ?></div>
			</a>
		</li>

		<?php if(auth()->check() && (auth()->user()->isSuperAdmin() || auth()->user()->role === 'admin' || auth()->user()->role === 'super_admin' || auth()->user()->hasRole(['admin', 'super_admin']))): ?>
		<!-- Events & Broadcast -->
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.certificates_events')); ?></span>
		</li>
		<!-- Certificate: Seen ONLY by Admin -->
		<li class="menu-item <?php echo e(request()->is('admin/certificates*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.certificates.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-certificate"></i>
				<div><?php echo e(__('erp.certificates')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/events*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.events.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-calendar-alt"></i>
				<div><?php echo e(__('erp.marriage_events')); ?></div>
			</a>
		</li>
		<!-- Beneficiary Payouts: Seen ONLY by Admin (Hidden from Agent) -->
		<li class="menu-item <?php echo e(request()->is('admin/payouts*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.payouts.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-hand-holding-usd"></i>
				<div><?php echo e(__('erp.payouts')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/whatsapp*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.whatsapp.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fab fa-whatsapp text-success"></i>
				<div><?php echo e(__('erp.whatsapp')); ?></div>
			</a>
		</li>

		<!-- Reports & System -->
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e(__('erp.reports_system')); ?></span>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/reports*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.reports.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-file-alt"></i>
				<div><?php echo e(__('erp.reports')); ?></div>
			</a>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/users*') || request()->is('admin/roles*') ? 'active open' : ''); ?>">
			<a href="javascript:void(0);" class="menu-link menu-toggle">
				<i class="menu-icon tf-icons fas fa-user-shield"></i>
				<div><?php echo e(__('erp.users')); ?></div>
			</a>
			<ul class="menu-sub">
				<li class="menu-item <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
					<a href="<?php echo e(route('admin.users.index')); ?>" class="menu-link">
						<div><?php echo e(__('erp.users')); ?></div>
					</a>
				</li>
				<li class="menu-item <?php echo e(request()->is('admin/roles*') ? 'active' : ''); ?>">
					<a href="<?php echo e(route('admin.roles.index')); ?>" class="menu-link">
						<div><?php echo e(__('erp.roles_permissions')); ?></div>
					</a>
				</li>
			</ul>
		</li>
		<li class="menu-item <?php echo e(request()->is('admin/settings*') ? 'active' : ''); ?>">
			<a href="<?php echo e(route('admin.settings.index')); ?>" class="menu-link">
				<i class="menu-icon tf-icons fas fa-cog"></i>
				<div><?php echo e(__('erp.settings')); ?></div>
			</a>
		</li>
		<?php endif; ?>
	</ul>
</aside><?php /**PATH C:\laragon\www\laravel_project\shrishyamcrm\project\resources\views/admin/layouts/elements/left_sidebar.blade.php ENDPATH**/ ?>