<footer class="content-footer footer bg-footer-theme">
    <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            , made with ❤️ by
            <a href="https://themeselection.com" target="_blank"
                class="footer-link fw-medium"><?php echo e(config('app.name')); ?></a>    
        </div>
        <div class="d-none d-lg-inline-block">
            <a href="#" class="footer-link me-4"
                target="_blank"></a>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\laravel_project\shrishyamcrm\project\resources\views/admin/layouts/elements/footer.blade.php ENDPATH**/ ?>