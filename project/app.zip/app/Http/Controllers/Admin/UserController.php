<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use App\Models\Agent;
use App\Services\NumberSeriesService;
use Illuminate\Support\Facades\Hash;
use App\Services\AuditService;

class UserController extends Controller
{
    public function index()
    {
        $users = User::with(['roles', 'roleModel', 'agent'])->latest()->paginate(15);
        $roles = Role::all();
        $agents = Agent::where('status', 'Active')->get();

        return view('admin.users.index', compact('users', 'roles', 'agents'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|string|unique:users,phone',
            'password' => 'required|min:6',
            'role_id' => 'required|exists:roles,id',
        ]);

        $role = Role::findOrFail($request->role_id);

        $user = User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'full_name' => $request->first_name . ' ' . $request->last_name,
            'slug' => \Str::slug($request->first_name . '-' . $request->last_name . '-' . rand(100, 999)),
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => Hash::make($request->password),
            'role' => $role->name,
            'role_id' => $role->id,
            'agent_id' => $request->agent_id ?: null,
            'country' => 'India',
            'status' => 'active',
        ]);

        $user->roles()->sync([$role->id]);

        // Auto-create and link Agent record if role is agent and no agent is linked
        if ($role->name === 'agent' && !$user->agent_id) {
            $agentCode = NumberSeriesService::getNextNumber('AGT', ['prefix' => 'AGT-', 'initial_value' => 1, 'padding' => 3]);
            $code = str_replace('-', '', $agentCode);
            $agent = Agent::create([
                'agent_code' => $agentCode,
                'name' => $user->full_name,
                'code' => $code,
                'mobile' => $user->phone,
                'email' => $user->email,
                'district' => 'Mahendragarh',
                'address' => $user->address ?: '',
                'commission_rate' => 5.0,
                'status' => 'Active',
                'user_id' => $user->id,
            ]);
            $user->update(['agent_id' => $agent->id]);
        }

        AuditService::log('create', 'users', (string)$user->id, null, ['name' => $user->full_name, 'role' => $role->name]);

        return back()->with('success', "User {$user->full_name} created successfully with role {$role->display_name}.");
    }

    public function show(Request $request, $id)
    {
        return $this->edit($request, $id);
    }

    public function edit(Request $request, $id)
    {
        $user = User::with(['roles', 'roleModel', 'agent'])->findOrFail($id);
        if ($request->wantsJson() || $request->ajax()) {
            return response()->json($user);
        }
        $users = User::with(['roles', 'roleModel', 'agent'])->latest()->paginate(15);
        $roles = Role::all();
        $agents = Agent::where('status', 'Active')->get();
        $editUser = $user;

        return view('admin.users.index', compact('users', 'roles', 'agents', 'editUser'));
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'email' => 'required|email|unique:users,email,' . $user->id,
            'phone' => 'required|string|unique:users,phone,' . $user->id,
            'role_id' => 'required|exists:roles,id',
        ]);

        $role = Role::findOrFail($request->role_id);

        $user->update([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'full_name' => $request->first_name . ' ' . $request->last_name,
            'email' => $request->email,
            'phone' => $request->phone,
            'role' => $role->name,
            'role_id' => $role->id,
            'agent_id' => $request->agent_id ?: null,
            'status' => $request->status ?? 'active',
        ]);

        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
            $user->save();
        }

        $user->roles()->sync([$role->id]);

        if ($role->name === 'agent' && !$user->agent_id) {
            $agentCode = NumberSeriesService::getNextNumber('AGT', ['prefix' => 'AGT-', 'initial_value' => 1, 'padding' => 3]);
            $code = str_replace('-', '', $agentCode);
            $agent = Agent::create([
                'agent_code' => $agentCode,
                'name' => $user->full_name,
                'code' => $code,
                'mobile' => $user->phone,
                'email' => $user->email,
                'district' => 'Mahendragarh',
                'address' => $user->address ?: '',
                'commission_rate' => 5.0,
                'status' => 'Active',
                'user_id' => $user->id,
            ]);
            $user->update(['agent_id' => $agent->id]);
        }

        AuditService::log('update', 'users', (string)$user->id, null, ['name' => $user->full_name, 'role' => $role->name]);

        return back()->with('success', "User {$user->full_name} updated successfully.");
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        if ($user->id === auth()->id()) {
            return back()->with('error', 'You cannot delete your own account.');
        }

        $user->delete();
        AuditService::log('delete', 'users', (string)$id);

        return back()->with('success', 'User deleted successfully.');
    }
}
