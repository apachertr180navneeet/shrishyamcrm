<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Agent;
use App\Models\User;
use App\Models\Role;
use App\Services\NumberSeriesService;
use App\Services\WhatsAppService;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AgentController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        if ($user && $user->isAgent() && $user->agent_id) {
            return redirect()->route('admin.agents.show', $user->agent_id);
        }

        // Auto-ensure any user with agent role has an Agent record
        $agentUsers = User::where(function($q) {
            $q->where('role', 'agent')
              ->orWhereHas('roles', fn($rq) => $rq->where('name', 'agent'));
        })->get();

        foreach ($agentUsers as $au) {
            if (!$au->agent_id) {
                $agent = Agent::where('user_id', $au->id)
                    ->orWhere('email', $au->email)
                    ->orWhere('mobile', $au->phone)
                    ->first();

                if (!$agent) {
                    $agentCode = NumberSeriesService::getNextNumber('AGT', ['prefix' => 'AGT-', 'initial_value' => 1, 'padding' => 3]);
                    $code = str_replace('-', '', $agentCode);
                    $agent = Agent::create([
                        'agent_code' => $agentCode,
                        'name' => $au->full_name,
                        'code' => $code,
                        'mobile' => $au->phone,
                        'email' => $au->email,
                        'district' => $au->city ?: 'Mahendragarh',
                        'address' => $au->address ?: '',
                        'commission_rate' => 5.0,
                        'status' => 'Active',
                        'user_id' => $au->id,
                    ]);
                } else {
                    $agent->update(['user_id' => $au->id]);
                }

                $au->update(['agent_id' => $agent->id]);
            }
        }

        $query = Agent::with(['members', 'payments', 'user']);

        if ($request->filled('search')) {
            $search = \App\Helpers\Helper::likeEscape($request->search);
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('agent_code', 'like', "%{$search}%")
                  ->orWhere('mobile', 'like', "%{$search}%")
                  ->orWhere('district', 'like', "%{$search}%");
            });
        }

        if ($request->filled('district')) {
            $query->where('district', $request->district);
        }

        $agents = $query->latest('id')->paginate(15)->withQueryString();
        $districts = Agent::distinct()->pluck('district')->filter();

        return view('admin.agents.index', compact('agents', 'districts'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();
        if ($user && $user->isAgent()) {
            abort(403, 'Unauthorized. Agents cannot register new agents.');
        }

        $request->validate([
            'name' => 'nullable|string|max:150',
            'first_name' => 'nullable|string|max:100',
            'last_name' => 'nullable|string|max:100',
            'mobile' => 'required|string|max:20',
            'email' => 'nullable|email|max:150',
            'district' => 'required|string|max:100',
            'commission_rate' => 'required|numeric|min:0|max:100',
            'password' => 'required|string|min:6',
        ]);

        // Compute full name, first name, last name
        if ($request->filled('first_name')) {
            $firstName = $request->first_name;
            $lastName = $request->last_name ?? '';
            $fullName = trim($firstName . ' ' . $lastName);
        } else {
            $fullName = $request->name ?: 'Agent User';
            $nameParts = explode(' ', trim($fullName));
            $firstName = $nameParts[0] ?? 'Agent';
            $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : ($request->district ?? 'Representative');
        }

        // 1. Unique agent code generation
        $agentCode = NumberSeriesService::getNextNumber('AGT', ['prefix' => 'AGT-', 'initial_value' => 1, 'padding' => 3]);
        $code = str_replace('-', '', $agentCode);
        $agentRole = Role::where('name', 'agent')->first();
        $email = $request->email ?: ('agent.' . strtolower(str_replace('-', '', $agentCode)) . '@shrishyam.org');

        // 2. Direct storage in Users table first
        $agentUser = User::where('email', $email)->orWhere('phone', $request->mobile)->first();

        if (!$agentUser) {
            $agentUser = User::create([
                'first_name' => $firstName,
                'last_name' => $lastName,
                'full_name' => $fullName,
                'slug' => Str::slug($fullName . '-' . rand(100, 999)),
                'email' => $email,
                'phone' => $request->mobile,
                'password' => Hash::make($request->password),
                'role' => 'agent',
                'role_id' => $agentRole?->id,
                'address' => $request->address ?? '',
                'city' => $request->district ?? '',
                'state' => 'Haryana',
                'country' => 'India',
                'status' => 'active',
            ]);
            if ($agentRole) {
                $agentUser->roles()->sync([$agentRole->id]);
            }
        } else {
            $agentUser->update([
                'first_name' => $firstName,
                'last_name' => $lastName,
                'full_name' => $fullName,
                'role' => 'agent',
                'role_id' => $agentRole?->id ?? $agentUser->role_id,
                'password' => Hash::make($request->password),
                'address' => $request->address ?? $agentUser->address,
                'city' => $request->district ?? $agentUser->city,
            ]);
            if ($agentRole) {
                $agentUser->roles()->sync([$agentRole->id]);
            }
        }

        // 3. Store in Agents table passing the user_id
        $agent = Agent::create([
            'agent_code' => $agentCode,
            'name' => $agentUser->full_name,
            'code' => $code,
            'mobile' => $agentUser->phone,
            'email' => $agentUser->email,
            'district' => $request->district,
            'address' => $request->address,
            'commission_rate' => $request->commission_rate,
            'status' => 'Active',
            'user_id' => $agentUser->id,
        ]);

        // 4. Pass agent_id back into user table
        $agentUser->update(['agent_id' => $agent->id]);

        return back()->with('success', "Agent {$agent->name} ({$agent->agent_code}) successfully created as user with login ID: {$agentUser->email}!");
    }

    public function show($id)
    {
        $user = auth()->user();
        if ($user && $user->isAgent() && $user->agent_id && (int)$id !== (int)$user->agent_id) {
            abort(403, 'Unauthorized access to other agent profiles.');
        }

        $agent = Agent::with(['members.scheme', 'payments.member', 'user'])->findOrFail($id);
        return view('admin.agents.show', compact('agent'));
    }

    public function edit(Request $request, $id)
    {
        $user = auth()->user();
        if ($user && $user->isAgent() && $user->agent_id && (int)$id !== (int)$user->agent_id) {
            abort(403, 'Unauthorized access.');
        }

        $agent = Agent::with(['members.scheme', 'payments.member', 'user'])->findOrFail($id);
        if ($request->wantsJson() || $request->ajax()) {
            return response()->json($agent);
        }

        $districts = Agent::distinct()->pluck('district')->filter();

        return view('admin.agents.edit', compact('agent', 'districts'));
    }

    public function update(Request $request, $id)
    {
        $user = auth()->user();
        if ($user && $user->isAgent() && $user->agent_id && (int)$id !== (int)$user->agent_id) {
            abort(403, 'Unauthorized access.');
        }

        $agent = Agent::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:150',
            'mobile' => 'required|string|max:20',
            'district' => 'required|string|max:100',
            'commission_rate' => 'required|numeric|min:0|max:100',
            'status' => 'nullable|string|in:Active,Inactive',
            'email' => 'nullable|email|max:150',
            'password' => 'nullable|string|min:6',
        ]);

        $agent->update([
            'name' => $request->name,
            'mobile' => $request->mobile,
            'email' => $request->email ?: $agent->email,
            'district' => $request->district,
            'address' => $request->address,
            'commission_rate' => $request->commission_rate,
            'status' => $request->status ?: $agent->status,
        ]);

        if ($agent->user) {
            $userData = [
                'full_name' => $agent->name,
                'phone' => $agent->mobile,
                'city' => $agent->district,
                'address' => $agent->address,
                'status' => strtolower($agent->status) === 'active' ? 'active' : 'inactive',
            ];
            if ($request->filled('email')) {
                $userData['email'] = $request->email;
            }
            if ($request->filled('password')) {
                $userData['password'] = \Illuminate\Support\Facades\Hash::make($request->password);
            }
            $agent->user->update($userData);
        }

        return redirect()->back()->with('success', "Agent {$agent->name} ({$agent->agent_code}) updated successfully.");
    }

    public function destroy($id)
    {
        $user = auth()->user();
        if ($user && $user->isAgent()) {
            abort(403, 'Unauthorized.');
        }

        $agent = Agent::findOrFail($id);
        $agent->delete();

        return redirect()->route('admin.agents.index')->with('success', "Agent {$agent->name} archived successfully.");
    }

    /**
     * Get login credentials and formatted WhatsApp message for agent
     */
    public function getCredentials(Request $request, $id)
    {
        $user = auth()->user();
        if ($user && $user->isAgent() && (int)$id !== (int)$user->agent_id) {
            abort(403, 'Unauthorized.');
        }

        $agent = Agent::with('user')->findOrFail($id);
        $credentials = WhatsAppService::getAgentCredentialsMessage($agent);

        return response()->json([
            'status' => 'success',
            'agent' => $agent,
            'user' => $agent->user,
            'login_url' => $credentials['login_url'],
            'username' => $credentials['username'],
            'email' => $credentials['email'],
            'mobile' => $agent->mobile,
            'whatsapp_url' => $credentials['url'],
            'message' => $credentials['message'],
        ]);
    }

    /**
     * Update/Reset agent login password & generate fresh credentials WhatsApp message
     */
    public function updateCredentials(Request $request, $id)
    {
        $currentUser = auth()->user();
        if ($currentUser && $currentUser->isAgent()) {
            abort(403, 'Unauthorized. Agents cannot reset credentials.');
        }

        $request->validate([
            'password' => 'required|string|min:6',
            'email' => 'nullable|email|max:150',
            'mobile' => 'nullable|string|max:20',
        ]);

        $agent = Agent::with('user')->findOrFail($id);

        if ($request->filled('mobile')) {
            $agent->mobile = $request->mobile;
        }
        if ($request->filled('email')) {
            $agent->email = $request->email;
        }
        $agent->save();

        $agentUser = $agent->user;
        $agentRole = Role::where('name', 'agent')->first();

        if (!$agentUser) {
            $nameParts = explode(' ', trim($agent->name));
            $firstName = $nameParts[0] ?? 'Agent';
            $lastName = isset($nameParts[1]) ? implode(' ', array_slice($nameParts, 1)) : ($agent->district ?? 'Representative');

            $email = $agent->email ?: ('agent.' . strtolower(str_replace('-', '', $agent->agent_code)) . '@shrishyam.org');
            $agentUser = User::create([
                'first_name' => $firstName,
                'last_name' => $lastName,
                'full_name' => $agent->name,
                'slug' => Str::slug($agent->name . '-' . rand(100, 999)),
                'email' => $email,
                'phone' => $agent->mobile,
                'password' => Hash::make($request->password),
                'role' => 'agent',
                'role_id' => $agentRole?->id,
                'city' => $agent->district,
                'address' => $agent->address ?: '',
                'state' => 'Haryana',
                'country' => 'India',
                'status' => 'active',
                'agent_id' => $agent->id,
            ]);
            $agent->update(['user_id' => $agentUser->id]);
        } else {
            $agentUser->update([
                'password' => Hash::make($request->password),
                'email' => $request->email ?: $agentUser->email,
                'phone' => $request->mobile ?: $agentUser->phone,
                'status' => 'active',
            ]);
        }

        $credentials = WhatsAppService::getAgentCredentialsMessage($agent, $request->password);

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'status' => 'success',
                'message' => "Login credentials updated for {$agent->name}.",
                'whatsapp_url' => $credentials['url'],
                'credentials_message' => $credentials['message'],
                'password' => $request->password,
                'username' => $credentials['username'],
                'login_url' => $credentials['login_url'],
            ]);
        }

        return redirect()->back()->with([
            'success' => "Credentials for {$agent->name} updated successfully! You can send them via WhatsApp.",
            'whatsapp_url' => $credentials['url'],
        ]);
    }
}
